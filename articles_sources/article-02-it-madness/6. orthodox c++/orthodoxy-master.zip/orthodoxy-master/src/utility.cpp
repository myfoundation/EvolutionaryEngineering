// Copyright: D.M., 2025-present
// SPDX-License-Identifier: GPL-3.0-or-later

#include "utility.h"
BEFORE_LLVM
#include <clang/AST/Decl.h>
#include <clang/AST/DeclCXX.h>
#include <clang/AST/DeclTemplate.h>
#include <clang/Basic/Version.h>
AFTER_LLVM

llvm::raw_ostream &Orthodoxy::error_message()
{
    return llvm::errs() << "orthodoxy ERROR: ";
}

llvm::raw_ostream &Orthodoxy::warning_message()
{
    return llvm::errs() << "orthodoxy WARNING: ";
}

bool Orthodoxy::TypeIsLvalueReference(clang::QualType qty)
{
    return TypeIsLvalueReference(qty.getTypePtrOrNull());
}

bool Orthodoxy::TypeIsLvalueReference(const clang::Type *ty)
{
    if (!ty) return false;
    clang::Type::TypeClass tc = ty->getTypeClass();
    return tc == clang::Type::TypeClass::LValueReference;
}

bool Orthodoxy::TypeIsRvalueReference(clang::QualType qty)
{
    return TypeIsRvalueReference(qty.getTypePtrOrNull());
}

bool Orthodoxy::TypeIsRvalueReference(const clang::Type *ty)
{
    if (!ty) return false;
    clang::Type::TypeClass tc = ty->getTypeClass();
    return tc == clang::Type::TypeClass::RValueReference;
}

bool Orthodoxy::TypeIsReferenceToNonConst(clang::QualType qty)
{
    return TypeIsReferenceToNonConst(qty.getTypePtrOrNull());
}

bool Orthodoxy::TypeIsReferenceToNonConst(const clang::Type *ty)
{
    if (!ty) return false;
    const clang::ReferenceType *rty = llvm::dyn_cast<clang::ReferenceType>(ty);
    return rty && !rty->getPointeeType().isConstQualified();
}

bool Orthodoxy::TypeIsAuto(clang::QualType qty)
{
    return TypeIsAuto(qty.getTypePtrOrNull());
}

bool Orthodoxy::TypeIsAuto(const clang::Type *ty)
{
    if (!ty) return false;
    return ty->getContainedAutoType() != nullptr;
}

bool Orthodoxy::TagIsClass(const clang::TagDecl *TD)
{
#if CLANG_VERSION_MAJOR >= 18
    return TD->getTagKind() == clang::TagTypeKind::Class;
#else
    return TD->getTagKind() == clang::TTK_Class;
#endif
}

bool Orthodoxy::TagIsEnumClass(const clang::TagDecl *TD)
{
    return TD->isEnum() && llvm::cast<clang::EnumDecl>(TD)->isScoped();
}

bool Orthodoxy::FunctionIsCopyConstructor(const clang::FunctionDecl *FD)
{
    const clang::CXXConstructorDecl *ctor = llvm::dyn_cast<clang::CXXConstructorDecl>(FD);
    return ctor && ctor->isCopyConstructor();
}

bool Orthodoxy::FunctionIsMoveConstructor(const clang::FunctionDecl *FD)
{
    const clang::CXXConstructorDecl *ctor = llvm::dyn_cast<clang::CXXConstructorDecl>(FD);
    return ctor && ctor->isMoveConstructor();
}

bool Orthodoxy::FunctionIsImplicitConversionConstructor(const clang::FunctionDecl *FD)
{
    const clang::CXXConstructorDecl *ctor = llvm::dyn_cast<clang::CXXConstructorDecl>(FD);
    return ctor && !ctor->isCopyOrMoveConstructor() && ctor->isConvertingConstructor(false);
}

bool Orthodoxy::FunctionIsAssignmentOperator(const clang::FunctionDecl *FD)
{
    return FD->getOverloadedOperator() == clang::OO_Equal;
}

bool Orthodoxy::FunctionIsCopyAssignmentOperator(const clang::FunctionDecl *FD)
{
    const clang::CXXMethodDecl *MD = llvm::dyn_cast<clang::CXXMethodDecl>(FD);
    return MD ? MD->isCopyAssignmentOperator() : false;
}

bool Orthodoxy::FunctionIsMoveAssignmentOperator(const clang::FunctionDecl *FD)
{
    const clang::CXXMethodDecl *MD = llvm::dyn_cast<clang::CXXMethodDecl>(FD);
    return MD ? MD->isMoveAssignmentOperator() : false;
}

bool Orthodoxy::NamedDeclIsStaticMember(const clang::NamedDecl *ND)
{
    const clang::VarDecl *VD;
    const clang::CXXMethodDecl *MD;
    return ND->isCXXClassMember() &&
        (((VD = llvm::dyn_cast<clang::VarDecl>(ND)) && VD->isStaticDataMember()) ||
         ((MD = llvm::dyn_cast<clang::CXXMethodDecl>(ND)) && MD->isStatic()));
}

unsigned int Orthodoxy::NamespaceDepth(const clang::NamespaceDecl *ND, bool countAnonymous)
{
    unsigned int depth =
        (countAnonymous ? 1 : !ND->isAnonymousNamespace());

    const clang::DeclContext *context = ND;
    while ((context = context->getParent()))
    {
        const clang::NamespaceDecl *ns =
            llvm::dyn_cast<clang::NamespaceDecl>(context);
        if (ns)
            depth += (countAnonymous ? 1 : !ns->isAnonymousNamespace());
    }

    return depth;
}

const clang::ClassTemplateSpecializationDecl *Orthodoxy::OuterTemplateSpecialization(const clang::DeclContext *DC)
{
    while (DC)
    {
        const clang::ClassTemplateSpecializationDecl *TSD =
            llvm::dyn_cast<clang::ClassTemplateSpecializationDecl>(DC);
        if (TSD)
            return TSD;
        DC = DC->getParent();
    }
    return NULL;
}

const clang::ClassTemplateSpecializationDecl *Orthodoxy::OutermostTemplateSpecialization(const clang::DeclContext *DC)
{
    const clang::ClassTemplateSpecializationDecl *TSD = OuterTemplateSpecialization(DC);
    const clang::ClassTemplateSpecializationDecl *nextTSD;
    while (TSD && (nextTSD = OuterTemplateSpecialization(TSD->getParent())))
        TSD = nextTSD;
    return TSD;
}
