// Copyright: D.M., 2025-present
// SPDX-License-Identifier: GPL-3.0-or-later

class MyClass
{
    MyClass();
    MyClass(const MyClass &); // EXPECT(copy-constructor)
    MyClass(MyClass &&);
    MyClass(int);
    explicit MyClass(float);
    ~MyClass();
};
