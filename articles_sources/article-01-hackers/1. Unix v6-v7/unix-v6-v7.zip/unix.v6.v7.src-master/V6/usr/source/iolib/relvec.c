relvec (ptr)
{
free(ptr);
}
